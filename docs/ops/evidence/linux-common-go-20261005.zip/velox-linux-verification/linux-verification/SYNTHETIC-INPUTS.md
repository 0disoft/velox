# 합성 입력 전용

이 폴더의 모든 JSON 입력은 cmd/velox-consumer-summary/main_test.go의 validObservation을 바탕으로 만든 합성 테스트 자료입니다. 실제 Windows 측정, 릴리스, 프로세스 추적, GitHub 실행 또는 성능 관측이 아닙니다.

원본 fixture의 Windows/PowerShell 측정 도구 이름·시각·버전·해시·수치를 유지해 기존 스키마와 필드로 집계 계약만 검사합니다. 합성임을 sampleId와 이 파일에 명시하며 스키마에 없는 필드는 추가하지 않습니다. 실행 환경의 실제 정보는 보고서와 environment 로그를 보세요.

raw에는 유효한 합성 관측 1개만 두고 요약은 입력 디렉터리 밖에 저장합니다. cases 하위는 각각 독립적인 부정/정책 검사 입력입니다.
