export PATH=/workspace/scratch/367af58cdf2a/fairyc-verify.SXgvR6US/tools/go/bin:$PATH
export GOTOOLCHAIN=local
export GOPATH=/workspace/scratch/367af58cdf2a/velox-verify.kq08wuqz/cache/gopath
export GOCACHE=/workspace/scratch/367af58cdf2a/velox-verify.kq08wuqz/cache/go-build
export GOMODCACHE=/workspace/scratch/367af58cdf2a/velox-verify.kq08wuqz/cache/go-mod
