#!/usr/bin/env python3
"""Independently verify retained CLI outputs, exits, schemas, source bytes and Go test inventory."""
import collections, hashlib, json, pathlib, zipfile
from jsonschema import Draft202012Validator, FormatChecker
here=pathlib.Path.cwd(); run=here.parent; e=run/'evidence'; v=here/'linux-verification'
rawschema=json.loads((here/'schema/consumer-e2e-v1.schema.json').read_text())
summaryschema=json.loads((here/'schema/consumer-e2e-summary-v1.schema.json').read_text())
raw_validator=Draft202012Validator(rawschema,format_checker=FormatChecker()); summary_validator=Draft202012Validator(summaryschema,format_checker=FormatChecker())
checks=[]
def check(name,ok,detail=''):
 checks.append({'name':name,'pass':bool(ok),'detail':detail}); assert ok,(name,detail)
def exit_code(name): return int((e/f'logs/{name}.exit-code.txt').read_text())
def summary(path):
 value=json.loads(path.read_text()); summary_validator.validate(value); return value
for name in ('pre-go-test-all','pre-go-vet-all','pre-go-test-consumer-summary','detailed-go-test-all'):
 check(name,exit_code(name)==0)
raw_validator.validate(json.loads((v/'raw/synthetic-observation.json').read_text()))
for name,n,missing in [('summary-expected-1',1,0),('summary-expected-2',2,1)]:
 path=v/('summary.json' if n==1 else 'summary-expected-2.json'); data=summary(path)
 check(name,exit_code(name)==(0 if n==1 else 1) and data['expectedSamples']==n and data['observedSamples']==1 and data['successCount']==1 and data['failureCount']==0 and data['missingCount']==missing and data['statistics']==dict.fromkeys(['minMs','p50Ms','p95Ms','maxMs'],123.457),json.dumps(data))
 log=(e/f'logs/{name}.log').read_text(); check(name+' stdout-matches-file',log.startswith(path.read_text()))
for case in ('malformed','duplicate','schema-violation'):
 check(case,exit_code('cli-'+case)==1 and not (v/f'case-outputs/{case}.json').exists(),'Nonzero, no output summary created')
for case in ('failed-sample','different-release','hosted-pass','hosted-fail','hosted-unverified','local-unverified'):
 data=summary(v/f'case-outputs/{case}.json')
 check(case+' exit',exit_code('cli-'+case)==(0 if case in ('hosted-pass','local-unverified') else 1))
 if case=='failed-sample': ok=data['failureCount']==1 and data['statistics'] is None and data['samples'][0]['failurePhase']=='build'
 elif case=='different-release': ok=data['releaseArchiveSha256'] is None and data['observedSamples']==2
 elif case=='hosted-pass': ok=data['evidenceLevel']=='hosted-runner-summary' and data['processEvidencePassCount']==1
 elif case=='hosted-fail': ok=data['evidenceLevel']=='hosted-runner-summary' and data['processEvidenceFailCount']==1
 elif case=='hosted-unverified': ok=data['evidenceLevel']=='hosted-runner-summary' and data['processEvidenceUnverifiedCount']==1
 else: ok=data['evidenceLevel']=='local-contract-summary' and data['processEvidenceUnverifiedCount']==1
 check(case+' details',ok,json.dumps(data))
for p in (v/'cases').rglob('*.json'):
 if p.parent.name not in ('malformed','schema-violation'): raw_validator.validate(json.loads(p.read_text()))
inputs=json.loads((v/'inputs-before.sha256.json').read_text()); check('synthetic input preservation',all(hashlib.sha256((here/p).read_bytes()).hexdigest()==h for p,h in inputs.items()),f'{len(inputs)} files byte-identical')
original=run/'original/velox'; originals={str(p.relative_to(original)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(original.rglob('*')) if p.is_file()}
changed=[rel for rel,d in originals.items() if not (here/rel).is_file() or hashlib.sha256((here/rel).read_bytes()).hexdigest()!=d]
check('source unchanged',not changed,f'{len(originals)} original source files; changed={changed}')
archive=pathlib.Path('/workspace/scratch/367af58cdf2a/velox-input/velox-linux-verification-5daf7ae(1).zip')
with zipfile.ZipFile(archive) as z:
 matches=all(hashlib.sha256(z.read('velox/'+rel)).hexdigest()==h for rel,h in originals.items())
 check('original matches ZIP',matches)
(e/'source-manifest.sha256.json').write_text(json.dumps(originals,indent=2)+'\n')
(e/'source-identity.json').write_text(json.dumps({'input_zip':archive.name,'input_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'claimed_implementation_baseline':'1e1be215b0cc979d46c0af5e3704a97f273c742d','identity_note':'Baseline is user/request-document supplied; ZIP contains no Git history. Exact archive SHA and all source file SHA-256 values identify executed bytes.','source_file_count':len(originals),'original_matches_zip':matches,'source_changes':changed,'go_mod':originals['go.mod'],'go_sum':originals['go.sum'],'third_party_go_webview2_file_count':sum(x.startswith('third_party/go-webview2/') for x in originals)},indent=2)+'\n')
events=[json.loads(line) for line in (e/'logs/detailed-go-test-all.log').read_text().splitlines()]
counts=collections.Counter(event['Action'] for event in events if event.get('Test')); tops=collections.Counter(event['Action'] for event in events if event.get('Test') and '/' not in event['Test'])
skips=[event for event in events if event['Action']=='skip' and event.get('Test')]
passpkgs=[event['Package'] for event in events if event['Action']=='pass' and not event.get('Test')]
notestpkgs=[event['Package'] for event in events if event['Action']=='skip' and not event.get('Test')]
check('all recorded tests passed or explicit skip',counts['fail']==0)
# Decode go list's concatenated JSON documents.
text=(e/'logs/root-package-list.log').read_text(); decoder=json.JSONDecoder(); packages=[]
while text.strip():
 data,end=decoder.raw_decode(text.lstrip()); packages.append(data); text=text.lstrip()[end:]
package_inventory=[{key:p.get(key,[]) for key in ('ImportPath','GoFiles','TestGoFiles','XTestGoFiles','IgnoredGoFiles')} for p in packages]
rootdirs={p['ImportPath'].removeprefix('github.com/0disoft/velox/') for p in packages}
omitted=[]
for path in original.rglob('*.go'):
 rel=path.relative_to(original)
 if str(rel).startswith('third_party/'): continue
 if str(rel.parent) not in rootdirs and str(rel.parent) not in omitted: omitted.append(str(rel.parent))
result={'package_count':len(packages),'passed_test_packages':len(passpkgs),'no_test_packages':len(notestpkgs),'test_and_subtest_actions':dict(counts),'top_level_actions':dict(tops),'runtime_skips':skips,'omitted_root_go_directories':sorted(omitted),'package_inventory':package_inventory}
(e/'coverage-inventory.json').write_text(json.dumps(result,indent=2)+'\n')
(e/'verification-assertions.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(f'PASS: {len(checks)} evidence assertions; {len(originals)} original files unchanged and ZIP-matching; {len(inputs)} synthetic inputs unchanged.')
print(json.dumps({k:v for k,v in result.items() if k!='package_inventory'},indent=2))
