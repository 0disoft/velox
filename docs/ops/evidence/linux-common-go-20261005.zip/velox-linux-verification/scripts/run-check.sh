#!/bin/bash
set -u
name=$1; shift
E=/workspace/scratch/367af58cdf2a/velox-verify.kq08wuqz/evidence
start=$(date -u +%Y-%m-%dT%H:%M:%SZ)
printf '%q ' "$@" > "$E/logs/$name.command.txt"; printf '\n' >> "$E/logs/$name.command.txt"
"$@" > "$E/logs/$name.log" 2>&1
code=$?
end=$(date -u +%Y-%m-%dT%H:%M:%SZ)
printf '%s\n' "$code" > "$E/logs/$name.exit-code.txt"
printf '%s\t%s\t%s\t%s\n' "$name" "$code" "$start" "$end" >> "$E/commands.tsv"
printf '%s EXIT=%s\n' "$name" "$code"
cat "$E/logs/$name.log"
exit 0
