#!/usr/bin/env python3
"""Run from the unchanged Velox source root. Every produced observation is synthetic."""
import copy, hashlib, json, pathlib, re
root=pathlib.Path('linux-verification')
source=pathlib.Path('cmd/velox-consumer-summary/main_test.go').read_text()
base=json.loads(re.search(r'const validObservation = `([\s\S]*?)`',source).group(1))
base['sampleId']='synthetic-linux-verification-1'
def save(path,value):
 path=root/path; path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(json.dumps(value,indent=2)+'\n')
save(pathlib.Path('raw/synthetic-observation.json'),base)
(root/'SYNTHETIC-INPUTS.md').write_text('''# 합성 입력 전용\n\n이 폴더의 모든 JSON 입력은 cmd/velox-consumer-summary/main_test.go의 validObservation을 바탕으로 만든 합성 테스트 자료입니다. 실제 Windows 측정, 릴리스, 프로세스 추적, GitHub 실행 또는 성능 관측이 아닙니다.\n\n원본 fixture의 Windows/PowerShell 측정 도구 이름·시각·버전·해시·수치를 유지해 기존 스키마와 필드로 집계 계약만 검사합니다. 합성임을 sampleId와 이 파일에 명시하며 스키마에 없는 필드는 추가하지 않습니다. 실행 환경의 실제 정보는 보고서와 environment 로그를 보세요.\n\nraw에는 유효한 합성 관측 1개만 두고 요약은 입력 디렉터리 밖에 저장합니다. cases 하위는 각각 독립적인 부정/정책 검사 입력입니다.\n''')
malformed=root/'cases/malformed/input.json'; malformed.parent.mkdir(parents=True,exist_ok=True); malformed.write_text('{"schemaVersion":')
for i in (1,2): save(pathlib.Path(f'cases/duplicate/{i}.json'),base)
unknown=copy.deepcopy(base); unknown['syntheticUndeclaredField']=True; save(pathlib.Path('cases/schema-violation/input.json'),unknown)
failure=copy.deepcopy(base); failure['outcome']='failure'; failure['error']={'phase':'build','code':'PHASE_FAILED'}
for key in ('acquisition','release','fixture','build'): failure[key]=None
save(pathlib.Path('cases/failed-sample/input.json'),failure)
second=copy.deepcopy(base); second['sampleId']='synthetic-linux-verification-2'; second['acquisition']['archiveSha256']='e'*64
save(pathlib.Path('cases/different-release/1.json'),base); save(pathlib.Path('cases/different-release/2.json'),second)
for status in ('pass','fail','unverified'):
 hosted=copy.deepcopy(base); hosted['evidenceLevel']='hosted-runner-evidence'; hosted['acquisition']['mode']='github-actions-artifact'; hosted['measurement']['osFileCacheState']='fresh-hosted-runner-when-executed-in-an-isolated-job'; hosted['build']['processTrace']['status']=status
 save(pathlib.Path(f'cases/hosted-{status}/input.json'),hosted)
local=copy.deepcopy(base); local['build']['processTrace']['status']='unverified'; save(pathlib.Path('cases/local-unverified/input.json'),local)
paths=list((root/'raw').rglob('*.json'))+list((root/'cases').rglob('*.json'))
manifest={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
(root/'inputs-before.sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(f'Created {len(paths)} explicitly synthetic inputs, one valid baseline plus isolated negative/policy cases.')
