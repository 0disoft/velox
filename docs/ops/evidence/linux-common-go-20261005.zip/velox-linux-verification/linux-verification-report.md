# Velox Linux 공통 Go 코드 및 집계 도구 검증 보고서

## 결론

첨부 ZIP의 원본 소스를 실제 Linux에서 실행한 결과, 요청한 `go test -count=1 ./...`, `go vet ./...`, `go test -count=1 -v ./cmd/velox-consumer-summary`는 모두 종료 코드 **0**이었다. 정상 합성 입력 집계는 종료 **0**, 기대 샘플 수를 2로 늘린 집계는 종료 **1**과 `missingCount: 1` 요약을 생성했다. 실패 정보를 보존하는 의도된 동작도 확인했다.

공통 코드의 Linux 이식성 결함은 이번 검증 범위에서 발견하지 못했다. **소스 수정은 없고 패치도 없다.** 원본 690개 파일이 ZIP 및 실행 사본과 바이트 단위로 일치했다. 전체 상세 재실행에는 최상위 실행 항목 323개 통과와 원래 조건에 따른 2개 제외가 있었다. Windows 네이티브 동작과 별도 `third_party/go-webview2` 모듈의 테스트는 미검증이다. 이 결과는 Linux 데스크톱 앱 지원을 의미하지 않는다.

## 입력과 소스 동일성

- 입력: `velox-linux-verification-5daf7ae(1).zip`
- ZIP SHA-256: `f38a62343b3de6f42055ee615f8d6e9cd8bd15721f99cd2abedf3e2434a4f8d9`
- 요청 문서가 명시한 구현 기준: `1e1be215b0cc979d46c0af5e3704a97f273c742d`. 이후 변경은 요청 문서 추가뿐이라는 사용자 제공 기준을 사용했다.
- ZIP에 Git 이력이 없으므로 커밋 동일성을 Git으로 독립 검증했다고 주장하지 않는다. 실제 실행 바이트는 위 ZIP 해시와 `source-manifest.sha256.json`의 파일별 SHA-256으로 식별한다.
- 고유 새 작업 폴더 `velox-verify.kq08wuqz`에 `original/velox`로 추출한 뒤 `work` 사본에서 실행했다. 원본 추출본과 업로드 ZIP을 보존했다. GitHub main으로 교체하지 않았다.
- `go.mod`, `go.sum`, 스키마 및 로컬 replace를 유지했다. `third_party/go-webview2` 80개 파일도 변경하지 않았다. 원본 대조 결과는 `source-identity.json`에 있다.
- `AGENTS.md`, `CONTRIBUTING.md`, `VALIDATION.md`, `CHECKLIST.md`, `.agents/context-map.md`, 관련 체크리스트, 제품 범위 및 ADR 0005, 집계 코드·테스트·스키마를 읽었다. 이번 요청의 직접 실행 지침에 따라 Mustflow나 명령 계약 등록은 사용하지 않았다.

## 실행 환경

| 항목 | 실제 값 |
| --- | --- |
| 실행 일시 | 2026-10-04 17:53 UTC 이후. 명령별 시작·종료는 `commands.tsv` |
| 배포판 | Debian GNU/Linux 13 (trixie), `DEBIAN_VERSION_FULL=13.6` |
| `uname -a` | `Linux 26eabc6b3339 6.18.44 #1 SMP Sat Sep 26 20:02:31 UTC 2026 x86_64 GNU/Linux` |
| 아키텍처 | `x86_64` / Go `amd64` |
| `go version` | `go version go1.26.7 linux/amd64` |
| `go env GOOS GOARCH CGO_ENABLED` | `linux`, `amd64`, `1` |
| Go 요구사항 | `go.mod:3`의 `go 1.26.0` 충족 |
| Windows 비교 환경 | 요청상 Go 1.27.1. 이번 Go 1.26.7과 다르므로 OS만 바꾼 동등 버전 비교는 아님 |
| C 컴파일러 | gcc 14.2.0. `CGO_ENABLED`는 기본값 1 유지 |
| 도구 선택 | 기존 작업의 `tools/go/bin/go` 1.26.7을 PATH 앞에 지정해 재사용. 시스템 `/usr/bin/go`는 Go 컴파일러가 아니어서 사용하지 않음 |
| 다운로드 정책 | `GOTOOLCHAIN=local`, `GOPROXY=https://proxy.golang.org,direct`, `GOSUMDB=sum.golang.org` |
| 캐시 | 이번 고유 작업 폴더의 새 `GOCACHE`, `GOMODCACHE`, `GOPATH`; 이전 프로젝트의 모듈 캐시를 재사용하지 않음 |
| 기타 플래그 | `GOFLAGS` 빈 값. VCS 플래그 강제 설정, Wine, PowerShell 설치 없음 |

`logs/environment.log`에 요구된 환경 명령 전체 출력을 남겼다. 전체 환경 변수나 인증정보는 출력하지 않았다. 명령 시각은 UTC이며 Go JSON 테스트 로그의 `+09:00` 표기는 실행 프로세스 로컬 시간대 형식이다. 같은 실제 시각을 가리킨다.

네트워크는 고정 모듈을 가져오는 데 사용 가능했다. `proxy.golang.org` HTTPS HEAD 응답은 200이었고, 새 캐시에 `github.com/santhosh-tekuri/jsonschema/v6 v6.0.3` 및 `golang.org/x/text v0.42.0` 다운로드가 성공했다. `go mod verify`도 종료 0, `all modules verified`였다. `go.dev/dl/` HEAD는 HTTP 405였지만 연결은 성립했다. 이는 HEAD 메서드 응답이며 설치 실패로 분류하지 않았다. 새 Go 설치는 필요하지 않았다.

재사용한 Go 압축 파일의 SHA-256은 `ffb5f8de10c62550dfddab66b36b57030721e0a44a3218e9e1181d7b59f121ca`로 기존 다운로드 체크섬 기록과 일치했다. 이번 실행에서는 배포 사이트의 체크섬을 새로 조회한 것은 아니다. 사용한 Go 바이너리 해시는 `logs/reused-toolchain.log`에 있다.

## 수정 전 필수 검증

모든 명령은 변경되지 않은 `work` 저장소 루트에서 실행했다. 각 `.log`는 표준 출력과 표준 오류 전체를 함께 담는다. 각각의 정확한 명령은 `.command.txt`, 종료 코드는 `.exit-code.txt`에 별도로 보존했다.

| 명령 | 종료 코드 | 판정 | 로그 이름 |
| --- | --- | --- | --- |
| `go test -count=1 ./...` | 0 | PASS, 단 아래의 원래 제외 조건 있음 | `pre-go-test-all` |
| `go vet ./...` | 0 | PASS, 진단 출력 없음 | `pre-go-vet-all` |
| `go test -count=1 -v ./cmd/velox-consumer-summary` | 0 | PASS, 최상위 5개 테스트 및 하위 16개 검사 | `pre-go-test-consumer-summary` |

테스트 캐시의 성공 결과를 재사용하지 않도록 요청대로 `-count=1`을 사용했다. 실패가 있어도 다음 명령을 실행하는 기록용 셸 래퍼를 사용했으며, 이번 필수 3개에는 실패가 없었다. 상세 테스트의 알 수 없는 플래그 진단은 `TestUsageAndSingleFileInput`의 의도된 오류 입력 출력이며 테스트 실패가 아니다.

## 실제 집계 CLI 실행

`cmd/velox-consumer-summary/main_test.go:14–27`의 `validObservation` 구조를 읽어 기존 스키마와 필드 이름을 유지했다. 표본 ID는 `synthetic-linux-verification-1`로 명시했다. `linux-verification/SYNTHETIC-INPUTS.md`에도 합성임을 기록했다.

**이 입력의 시각, Windows 환경 문자열, PowerShell 측정 도구명, 릴리스 버전, 해시, 크기 및 기간은 모두 테스트용 값이다. 실제 Windows 측정이나 프로세스 추적을 수행한 결과가 아니다.** JSON의 고정 스키마 필드를 Linux 값으로 임의 변경하거나 추가하지 않았다. 실제 실행 환경은 앞 절의 Linux 환경이다. 집계 출력의 `123.457 ms` 역시 성능 측정값으로 해석하면 안 된다.

정상 입력 디렉터리에는 유효한 JSON 하나만 두었다. 출력은 그 디렉터리 밖에 저장했다.

```sh
go run ./cmd/velox-consumer-summary --results-root linux-verification/raw --output linux-verification/summary.json --expected-samples 1
go run ./cmd/velox-consumer-summary --results-root linux-verification/raw --output linux-verification/summary-expected-2.json --expected-samples 2
```

| 입력 조건 | 종료 코드 | 실제 요약 | 계약 판정 |
| --- | --- | --- | --- |
| 유효한 합성 관측 1개, 기대 1개 | 0 | `expectedSamples=1`, `observedSamples=1`, `successCount=1`, `failureCount=0`, `missingCount=0` | PASS |
| 같은 관측 1개, 기대 2개 | 1 | `expectedSamples=2`, `observedSamples=1`, `successCount=1`, `failureCount=0`, `missingCount=1` | PASS, 의도된 non-zero |

두 요약 파일을 각각 보존했다. 둘 다 `local-contract-summary`이며, 프로그램 내부의 요약 스키마 검증을 통과했다. 별도의 Python `jsonschema` 검증과 값 단언으로도 확인했다. 로그의 JSON 표준 출력이 저장 파일과 일치하는지 검증했다. `go run`의 실패 로그 끝에 나오는 `exit status 1`은 하위 프로그램 종료 1을 반영한다.

## 부정 입력과 증거 정책 연결

아래의 기존 Go 테스트가 모두 통과했다. 추가로 격리된 합성 입력 폴더에서 실제 CLI를 실행해 파일 생성 여부, 반환 코드 및 핵심 필드까지 확인했다. 부정 입력의 종료 1은 정상적인 거부 동작이므로 검증 실패로 세지 않는다.

| 조건 | 기존 테스트 및 위치 | 추가 CLI 결과 |
| --- | --- | --- |
| 잘못된 JSON | `TestInvalidEvidenceDoesNotWriteSummary/trailing-value`, `main_test.go:130` | 추가로 실제 잘린 JSON `{"schemaVersion":` 실행. 종료 1, `unexpected EOF`, 요약 미생성 |
| 중복 ID | 위 테스트의 `duplicate`, `duplicate-case`, `main_test.go:126–127` | 같은 ID 2개 입력: 종료 1, 요약 미생성 |
| 스키마 위반 | `unknown-field`, `missing-field`, `negative-duration`, `bad-date`, `missing-success-build`, `hosted-with-local-clock`, `main_test.go:128–134` | 허용하지 않은 추가 필드: 종료 1, 요약 미생성 |
| 실패 샘플 | `TestIncompleteEvidenceStillWritesSummary/failure`, `main_test.go:87–118` | 종료 1, 요약 생성, `failureCount=1`, `failurePhase=build`, `statistics=null` |
| 다른 릴리스 해시 | 같은 테스트의 `different-release`, `main_test.go:107` | 서로 다른 acquisition archive SHA-256: 종료 1, 2개 샘플 보존, `releaseArchiveSha256=null` |
| hosted process pass | `TestHostedAndLocalProcessPolicy`, `main_test.go:146–154` | 종료 0, `hosted-runner-summary`, `processEvidencePassCount=1` |
| hosted process fail | `TestIncompleteEvidenceStillWritesSummary/hosted-fail`, `main_test.go:109` | 종료 1, 요약 생성, `processEvidenceFailCount=1` |
| hosted process unverified | 같은 테스트의 `hosted-unverified`, `main_test.go:108` | 종료 1, 요약 생성, `processEvidenceUnverifiedCount=1` |
| local process unverified | `TestHostedAndLocalProcessPolicy`, `main_test.go:151–154` | 종료 0, `local-contract-summary`, unverified 1개 유지 |

관련 구현 위치는 `cmd/velox-consumer-summary/main.go` 기준이다.

- 124–139행: 원시 JSON 스키마 검증과 집계 오류 처리. 중복 ID처럼 유효한 요약 자체가 없으면 쓰기 전에 반환한다.
- 145–156행: 요약 스키마 검증 후, 불완전 증거도 파일과 표준 출력에 기록하고 원래 오류를 반환한다.
- 184–193행: 첫 JSON 디코딩 실패와 뒤따르는 추가 JSON 값을 거부한다.
- 236–287행: 대소문자 비구분 ID 중복, 샘플 수, 실패 수, acquisition 릴리스 해시, hosted 프로세스 상태를 집계·판정한다.
- 71–75행: 오류 시 명령 종료 코드 1을 설정한다.

기존 `missing-success-build`라는 테스트명은 실제로는 성공형 레코드의 outcome만 failure로 바꾼 스키마 불일치를 검사한다. 성공 레코드에서 build 필드를 삭제한 독립 사례라고 확대 해석하지 않았다. 해시 불일치 검사도 앱 산출물의 `build.archiveSha256`이 아니라 릴리스 획득물인 `acquisition.archiveSha256` 비교다.

추가 CLI의 정확한 명령·전체 로그·종료 코드는 `logs/cli-*`에 있고, 입력은 `linux-verification/cases/`, 생성된 요약은 `linux-verification/case-outputs/`에 있다. 잘못된 입력으로 요약이 생성되지 않은 3개 사례는 해당 출력 파일이 없는 것이 의도된 결과다. 모든 합성 입력 12개가 실행 전후 바이트 단위로 동일했다.

## 전체 범위와 실제 제외 항목

수정 없이 추가로 `go test -count=1 -json ./...`을 종료 0으로 실행하여 처음의 간략 로그에 드러나지 않는 제외 항목을 확인했다. `go list -e -json ./...`과 함께 `coverage-inventory.json`에 정리했다.

- 루트 모듈의 Linux 대상 패키지 50개: 테스트 패키지 39개 PASS, 테스트 파일 없는 패키지 11개.
- 최상위 실행 항목 325개: PASS 323개, SKIP 2개, FAIL 0개.
- 부모 테스트·하위 테스트·fuzz seed 항목을 모두 포함한 이벤트 기준: 실행 516개, PASS 514개, SKIP 2개. 부모와 자식이 함께 세어지므로 516개를 독립 최상위 테스트 수로 해석하지 않는다.
- 일반 `go test`의 fuzz seed 실행 범위이며, 장시간 fuzz 캠페인·race 검사는 실행하지 않았다.

| 실제 runtime SKIP | 원인과 위치 | 분류 |
| --- | --- | --- |
| `internal/runtimeconfig/TestContainedPathRejectsWindowsDriveRelativePath` | `config_test.go:267–273`: 비-Windows에서는 `Windows drive-relative paths are platform-specific`로 제외 | 정상 Windows 전용 검증 |
| `internal/signingrecord/TestDryRunSchemaFixture` | `record_test.go:271–281`: `VELOX_SIGNING_RECORD_RESULT is not set`로 제외. 외부 출력 경로를 지정해야 동작하는 선택적 fixture 기록 테스트 | 선택적 환경 설정 미충족, 공통 코드 결함 아님 |

이 2개는 기존 조건에 따른 제외다. 테스트를 수정·삭제하거나 강제 skip을 추가하지 않았다. 심볼릭 링크 생성 권한에 따라 제외될 수 있는 다른 테스트들은 이번 실행에서 제외되지 않았다.

Windows 빌드 태그와 파일명으로 제외된 구현·테스트는 Linux에서 실행되지 않는 것이 정상이다. 포함된 패키지 내 `IgnoredGoFiles` 목록 73개는 `coverage-inventory.json`에 있다. 추가로 `cmd/velox-setup`, `tests/startup` 디렉터리는 Windows 전용 파일들만 있어 이번 루트 패키지 목록에 없었다. `scripts/windows-icon.go`는 `//go:build ignore`이므로 도구성 별도 소스다.

`cmd/velox-host/main_other.go:1–12`는 Linux에서 지원하지 않는 플랫폼 메시지와 종료 5를 내는 stub이다. 이번 Go 테스트에서 이 패키지가 컴파일되었다는 사실은 호스트 UI 실행 성공이 아니다. 이 stub을 데스크톱 앱으로 실행하지 않았다. 공통 runner/CLI 테스트의 Windows 준비 상태와 호스트 실행은 주입된 callback 및 가짜 호스트 바이트로 검사된다 (`internal/runner/runner_test.go:19–35,94–105`, `internal/cli/quickstart_test.go:30–41`).

## 미검증 범위와 남은 위험

다음은 실행하거나 통과했다고 주장하지 않는다.

- 실제 Windows WebView2, 네이티브 대화상자, 트레이, 알림, 전역 단축키, 작업표시줄, 창 동작, 클립보드 및 Windows 프로세스 추적.
- 실제 Windows 설치·제거, Start Menu 바로가기, 레지스트리 통합, GUI 호스트 실행. 공통 installer engine 테스트는 OS 통합을 주입해 검사하며 비-Windows 실제 설치 구현은 지원 오류를 반환한다 (`internal/installer/install_test.go:55–62`, `internal/installer/platform_other.go:1–8`).
- 별도 모듈 `third_party/go-webview2`의 테스트. 루트 `go.mod:16`의 local replace는 유지했지만 `./...`는 중첩 Go 모듈 안의 테스트를 자동 실행하지 않는다. `third_party/go-webview2/go.mod:1–3`에 독립 모듈이 있다. 일부 fork 소스의 gofmt hygiene 검사는 네이티브 테스트 실행을 대체하지 않는다.
- Windows 1.27.1과 같은 Go 버전에서의 Linux 재검증, 다른 Linux 배포판·아키텍처, `CGO_ENABLED=0` 별도 실행, race 및 확장 fuzz.
- TypeScript/Bun 예제 테스트, 브라우저 UI, Windows 측정 스크립트, 릴리스 번들 생성·서명 및 hosted CI. 이번 작업은 요청된 공통 Go 도구 검증이다.

Wine과 PowerShell을 설치·사용하지 않았다. Windows 실행파일을 Linux에서 실행하지 않았고, Git 메타데이터를 만들거나 검증을 우회하지 않았다. GitHub 이슈·PR·푸시·태그·릴리스는 생성하지 않았다.

## 실패 분류와 수정 전후 상태

| 분류 | 관측 결과 | 처리 |
| --- | --- | --- |
| 환경 제약 | 요구 Go 재사용 및 모듈 다운로드 가능. 선택적 signing fixture 출력 경로는 미설정 | 필수 검증을 막는 환경 장애 없음. 선택적 제외 1개 명시 |
| Windows 전용 검증 | 빌드 조건으로 제외된 소스·테스트와 drive-relative runtime SKIP | 정상 제외, Windows에서 별도 검증 필요 |
| 테스트의 잘못된 OS 가정 | 실행된 공통 테스트에서 실패 미발견 | 변경 없음 |
| 실제 공통 코드의 이식성 결함 | 이번 Linux 실행에서 재현된 결함 없음 | 수정·패치 없음 |
| 합성 부정 입력의 non-zero | 누락·실패·불일치·잘못된 입력을 예상대로 거부 | 테스트 계약 PASS, 제품 결함으로 분류하지 않음 |

**수정 전 결과:** 필수 3개 명령 PASS, 정상·부정 CLI 계약 PASS. 위 제외 범위를 포함한다.

**수정 후 결과:** 해당 없음. 소스 변경이 없으므로 수정 후 검증을 수행했다고 표기하지 않는다. 추가 상세 재실행·스키마 검증·원본 해시 대조는 모두 같은 원본 코드 상태의 보강 검증이다.

소스 오브 트루스 문서, API, DB, 저장소 hygiene 설정, runner, 의존성, 버전, 스키마의 변경은 모두 **없음**이다. 검증 보고서·기록·합성 입력만 별도로 생성했다. `verification-assertions.json`의 27개 증거 단언을 모두 통과했고, 최종 소스 동일성 대조도 별도 로그로 남겼다.

## 반환물과 재현

이 ZIP에는 다음이 포함된다.

- `linux-verification-report.md`: 이 보고서
- `logs/`: 명령별 전체 출력, 명령 문자열, 종료 코드
- `commands.tsv`: 각 명령의 UTC 시작·종료와 반환 코드
- `linux-verification/`: 명시적으로 합성인 원시 입력, 부정 사례, 실제 출력 JSON, 입력 해시
- `coverage-inventory.json`: 실제 Linux 패키지·테스트·제외 목록
- `source-identity.json`, `source-manifest.sha256.json`: 원본 ZIP 및 파일 동일성 증거
- `verification-assertions.json`: 출력·종료·스키마·보존 검증 결과
- `scripts/`: 합성 입력 생성 및 이번 결과 대조에 사용한 보조 스크립트
- `reference/`: 이번 결과 확인에 필요한 원본 집계 코드·테스트·스키마·모듈 선언 사본
- `SHA256SUMS`: 번들 파일별 무결성 해시

원본 저장소 전체와 Go/모듈 캐시는 중복 첨부하지 않았다. 수정이 없으므로 `.patch`는 포함하지 않았다. 다시 실행하려면 동일한 입력 ZIP을 새로 추출하고 Go 1.26.0 이상을 준비한 뒤 저장소 루트에서 위 필수 3개 명령을 실행한다. `scripts/make-synthetic-inputs.py`를 저장소 루트에서 실행하면 같은 합성 입력 세트를 만들 수 있다. 생성되는 `linux-verification` 경로가 비어 있는 새 사본을 사용한다. 이어 이 보고서의 두 `go run` 명령을 실행한다. 결과 대조 스크립트는 이번 보존 디렉터리 및 원본 ZIP 경로를 사용한 기록용 도구이므로 다른 환경에서는 해당 경로를 맞춰야 한다.
